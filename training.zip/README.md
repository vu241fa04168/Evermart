# Fieldnote Commerce

Phase 2 backend foundation for a MERN e-commerce platform. The client remains a Phase 1 shell; customer and admin UI flows are intentionally not implemented yet.

## Requirements

- Node.js 20 or newer
- npm 10 or newer
- MongoDB 7 or newer running as a local replica set named `rs0`

## Install

```powershell
npm run install:all
Copy-Item server\.env.example server\.env
```

Set a real `JWT_SECRET` in `server/.env`. The default MongoDB URL expects a local `rs0` replica set so later checkout transactions can use MongoDB sessions safely.

For Phase 2, also set `ADMIN_EMAIL`, `ADMIN_PASSWORD` (at least 16 characters), and `COOKIE_SECURE=false` for local HTTP development. Public registration always creates a customer account; it cannot assign an admin role.

## Start

```powershell
npm run dev
```

The client runs at `http://localhost:5173` and the API runs at `http://localhost:5000`.

The customer storefront is configured through `client/.env` when a non-default API URL is needed:

```powershell
Copy-Item client\.env.example client\.env
```

## Customer storefront

The React client now includes API-backed customer routes for the home page, paginated catalog, product details and verified reviews, authentication, persistent cart, wishlist, COD checkout, order confirmation, order history and cancellation, profile/address management, Privacy Policy, and Terms and Conditions. Axios sends credentials for the HTTP-only authentication cookie.

## Admin dashboard

Admin routes are available at `/admin`, `/admin/products`, `/admin/categories`, `/admin/orders`, and `/admin/customers`. They require an authenticated user with the server-side `admin` role. Dashboard revenue is the sum of delivered orders only; customer counts, product counts, orders, stock warnings, and customer history are read from MongoDB. Product archiving hides inactive products from public catalog and detail endpoints while preserving their records.

## Health checks

```powershell
Invoke-WebRequest http://localhost:5000/api/health/ping
Invoke-WebRequest http://localhost:5000/api/health
```

`/api/health/ping` verifies the HTTP process. `/api/health` reports `connected` or `disconnected` for MongoDB and returns HTTP 503 until the database is available.

## Local MongoDB replica set

Start `mongod` with replica-set support, for example:

```powershell
mongod --dbpath C:\data\db --replSet rs0 --port 27017
```

In a second terminal, initialize it once:

```powershell
mongosh --port 27017 --eval "rs.initiate()"
```

After the replica set reports a primary, start the application. Do not commit `server/.env` or production secrets.

## Phase 2 API tests and admin seed

```powershell
npm --prefix server test
npm --prefix server run seed:admin
npm --prefix server run seed:catalog
```

The admin seed reads credentials only from `server/.env`, hashes the password with bcrypt, and never prints it. The API uses an HTTP-only `fieldnote_token` cookie and requires credentials-enabled CORS for browser clients.

`seed:catalog` creates or updates three categories and eight realistic products using stable Unsplash image URLs. It intentionally creates no reviews and leaves rating, review count, and popularity at zero until actual application activity produces those values. Both seed commands are safe to run repeatedly.

## Phase 3 order and review APIs

```text
POST  /api/orders
GET   /api/orders
GET   /api/orders/:id
POST  /api/orders/:id/cancel
PATCH /api/orders/:id/status             Admin, cannot bypass cancellation inventory rules
GET   /api/products/:productId/reviews
POST  /api/products/:productId/reviews   Verified purchaser of a delivered order only
```

Order placement runs in a MongoDB transaction. It reads current product prices, atomically decrements stock with a stock predicate, stores a shipping-address snapshot, creates a COD order with separate `orderStatus` and `paymentStatus`, and clears the persistent cart in the same transaction. Concurrent attempts that exceed stock are rejected without partial orders.

Cancellation is eligible only while an order is `Processing`. It restores each item in the same transaction and records `inventoryRestoredAt`, making repeated cancellation unable to restore inventory twice. Reviews require a delivered order containing the product, enforce one review per user/product, and update product rating aggregates from persisted review documents.
